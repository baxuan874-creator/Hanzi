package com.hanzijourney.app.ui.theme

import androidx.compose.ui.unit.dp

object Spacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
    /** Minimum touch target size. */
    val touchTarget = 48.dp
}
