# CHANGELOG

## 0.0.1-phase0 (chưa build)
- Phase 0 / Task 1: khung dự án Android (Kotlin, Compose, Material 3), theme skeleton, màn hình shell, icon gốc, GitHub Actions build debug APK.

## 0.0.2-phase0 (chưa build)
- Phase 0 / Task 2: thêm Room (HanziDatabase, bảng curriculum_version, schema export), DataStore (SettingsRepository: âm thanh, giảm chuyển động, chế độ tối), AppContainer (DI thủ công), lớp HanziApp, KSP.

## 0.0.3-phase1 (chưa build)
- Phase 1 / Task 1: design tokens (màu sáng/tối, spacing, shape, typography), component EmptyState, Navigation Compose với 5 tab (Trang chủ, Học, Từ vựng, Ôn tập, Hồ sơ), 5 màn hình trạng thái trống. Không dùng dữ liệu giả.

## 0.0.4-phase1 (chưa build)
- Phase 1 / Task 2: component dùng chung (HanziButton, StatusBadge, HanziProgressBar, LessonCard, LearnMap); màn Hồ sơ có lựa chọn giao diện Theo hệ thống/Sáng/Tối lưu bằng DataStore và áp dụng cho toàn app (ProfileViewModel).

## (docs) Phase 2 / Task 1
- Thêm docs/SYLLABUS_LOCK.md (khóa tạm đề cương HSK 3.0 bản 2025-11) và tools/fetch_syllabus.sh (tải PDF + sinh checksum). Không đổi mã app.

## (content) Phase 2 / Task 2
- content_work/hsk3_l1_vocab_working.csv (300 từ Level 1), tools/validate_level1.py (chạy trong CI), docs/EXTRACTION_REPORT_L1.md; chép đầy đủ tài liệu dự án vào docs/ (các bản zip trước thiếu); cập nhật THIRD_PARTY_NOTICES và SYLLABUS_LOCK. Không đổi mã app.

## (content) Phase 2 / Task 3 (một phần)
- tools/extract_l1_from_pdf.py (trích 246 chữ nhận mặt, dump trang ngữ pháp), tools/selftest_extract.py (chạy trong CI), validator kiểm tra thêm file chữ nếu có.

## (content) Phase 2 / Task 3b
- content_work/hsk3_l1_grammar_working.csv (70 điểm ngữ pháp Level 1), validator kiểm tra file ngữ pháp và đối chiếu từ với 300 từ, cập nhật báo cáo/notices/lock.

## (content) Phase 2 / Task 3c
- content_work/hsk3_l1_chars_working.csv (246 chữ nhận mặt Level 1), cập nhật script trích và báo cáo. Giải thích chênh 248/246: 店, 饺.

## (content) Phase 2 / Task 4
- content_work/hsk3_l1_structure_working.json (16 chương, 47 bài, 300 từ + 70 ngữ pháp, mỗi mục đúng một lần), tools/build_l1_structure.py (kế hoạch gốc), docs/CURRICULUM_MAP_L1.md, validator kiểm tra cấu trúc (tiên quyết, giới hạn bài, phủ đủ), CI chạy cả build_l1_structure.py. Không đổi mã app.

## 0.0.5-phase2 (chưa build)
- Phase 2 / Task 5: bộ nạp nội dung bằng Kotlin (kotlinx.serialization): ContentModels, ContentPackParser, ContentValidator, ContentImporter, AssetContentSource; content.db (Room) tách khỏi hanzi.db; test đơn vị với dữ liệu giả (ContentPackTest); workflow chạy test đơn vị trước khi build; bước đăng Release không còn làm đỏ cả build. Không đóng gói dữ liệu HSK.

## (content) Phase 2 / Task 6
- Bài mẫu 004 "Xin chào" tự soạn (content_authoring/lesson_004.json): 12 từ có nghĩa tiếng Việt và ví dụ, 1 điểm ngữ pháp, 11 bài tập; tools/build_pack.py, tools/validate_pack.py (kèm quy tắc chỉ dùng chữ đã học); gói content_work/packs/hsk3_l1_sample_lesson004.pack.json; Kotlin: thêm review_status draft_unreviewed, kiểm tra sentence_ordering, SamplePackTest (kiểm tra gói thật bằng validator của app); CI chạy build/validate gói. Không đổi giao diện app.

## 0.0.6-phase3 (chưa build)
- Phase 3 / Task 1: trình học bài v1. Tab Học liệt kê bài từ content.db (bản debug tự nạp gói mẫu); màn học bài: mục tiêu, thẻ từ, ngữ pháp, bài tập (trắc nghiệm, điền chỗ trống, sắp xếp câu, nhập chữ), phản hồi có giải thích, làm lại câu sai một lần, màn kết quả. Logic LessonSession/ExerciseChecker có test đơn vị (kể cả chạy hết bài mẫu). Chưa lưu tiến độ.
